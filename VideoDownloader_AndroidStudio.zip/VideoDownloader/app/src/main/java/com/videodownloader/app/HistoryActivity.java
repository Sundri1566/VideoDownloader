package com.videodownloader.app;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class HistoryActivity extends AppCompatActivity {

    private LinearLayout llHistory;
    private static final String PREF_NAME = "VidSaverHistory";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        llHistory = findViewById(R.id.llHistory);
        loadHistory();

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnClear).setOnClickListener(v -> {
            getSharedPreferences(PREF_NAME, MODE_PRIVATE).edit().remove("history").apply();
            llHistory.removeAllViews();
            showEmpty();
        });
    }

    private void loadHistory() {
        SharedPreferences prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        String historyJson = prefs.getString("history", "[]");
        try {
            JsonArray arr = new Gson().fromJson(historyJson, JsonArray.class);
            if (arr.size() == 0) { showEmpty(); return; }
            for (int i = arr.size() - 1; i >= 0; i--) {
                JsonObject item = arr.get(i).getAsJsonObject();
                addHistoryItem(
                    item.get("title").getAsString(),
                    item.get("filename").getAsString(),
                    item.get("time").getAsLong()
                );
            }
        } catch (Exception e) {
            showEmpty();
        }
    }

    private void addHistoryItem(String title, String filename, long time) {
        View view = LayoutInflater.from(this).inflate(R.layout.item_history, llHistory, false);
        ((TextView) view.findViewById(R.id.tvHistTitle)).setText(title);
        String ext = filename.endsWith(".mp3") ? "AUDIO" : "VIDEO";
        ((TextView) view.findViewById(R.id.tvHistType)).setText(ext);
        String dateStr = new SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(new Date(time));
        ((TextView) view.findViewById(R.id.tvHistTime)).setText(dateStr);
        llHistory.addView(view);
    }

    private void showEmpty() {
        TextView tv = new TextView(this);
        tv.setText("No downloads yet");
        tv.setTextColor(0xFF888899);
        tv.setTextSize(16);
        tv.setPadding(0, 80, 0, 0);
        tv.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        llHistory.addView(tv);
    }
}
